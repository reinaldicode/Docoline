<?

include 'header.php';
include 'koneksi.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<head profile="http://www.google.com">
	
	<html>
<br />
<br />
<br />
<br />
<br />

<h2>Work Instruction List</h2>
<a href="wi_prod.php" class="btn btn-primary" style="margin-left:50px;">Production</a>
<a href="wi_other.php" class="btn btn-primary" >Others</a>
			
			
		

<? 

?>
