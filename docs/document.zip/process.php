<?

include 'header.php';
include 'koneksi.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<head profile="http://www.google.com">
	
	<html>
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<?
			include ('koneksi.php');
			
			
			if($status=='Approved')	{
				if(isset($_POST['upload'])){
					if(empty($_FILES['baru'])){
					die("File tidak bisa diupload");
					}
					$tmp_file = $_FILES['baru']['tmp_name'];
					$nma_file = $_FILES['baru']['name'];
					if(copy($tmp_file, "document/".$nma_file)){
					echo "File $nma_file Berhasil Disalin";
					//unlink("document/".$filelama);
					}
					else {
					echo "File gagal disalin";
					}
					}
				
				
			
				//echo $sql2;

				$query="update docu set file='$nma_file', status='Secured' where no_drf=$drf";
				
				$hasil=mysql_query($query);
				//echo $query;
				
				}

				if ($status=='Secured'){
					$query="update docu set status='Obsolete' where no_drf=$drf";
				
				$hasil=mysql_query($query);
				}


				
				

					
				
				
				if ($hasil)
				{
					
					
					?>
					<script language='javascript'>
							alert('Document Updated');
							document.location='index_login.php';
						</script>
					<?
					
				}else
				{
					echo "<center>";echo "No Database Connection";
					
				}		
			
			
			?>
			
			
			</html>

<? 

?>
