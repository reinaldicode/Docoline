<?php
 include ('koneksi.php');
 $query="delete from rev_doc where id='$id' ";
// $id_doc=
	$hasil=mysql_query($query);
	if ($hasil){
	?>
	<script language='javascript'>
							alert('Approver removed');
							document.location='my_doc.php';
						</script>
						<?
	}
	
	
	
	?>