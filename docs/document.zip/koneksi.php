<?php
$mssqlHost = "localhost";
$mssqlUser = "root";
$mssqlPass = "123456789";
$mssqlDB = "doc";
$link = mysql_connect($mssqlHost,$mssqlUser,$mssqlPass) or die ('Tidak dapat melakukan koneksi Server on '.$mssqlHost);
$db = mysql_select_db($mssqlDB, $link) or die("Tidak dapat menggunakan database");

//if ($link){echo "berhasil";}
?>