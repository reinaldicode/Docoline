<?php

include('header.php');
?>
<!DOCTYPE html>
<head>
<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
 
<script src="highchart/js/highcharts.js"></script>
 <script src="js/exporting.js"></script>

<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
</head>






<br />
<br />
<br />
<br />


 
  

<div id="profile">
<div class="alert alert-info" role="alert"><b id="welcome">Welcome : <i><?php echo $name; ?>, anda login sebagai <?php echo $state; ?></i></b></div>
</div>

<div class="well well-lg">
<img src="images/stamped.jpg" class="img-responsive" alt="Responsive image"></img>
<div class="col-xs-2"></div>
<div class="col-xs-6">
<div class="alert alert-warning" role="alert" style="margin-top:-110px;margin-left:-70px;"><b id="welcome">Bapak / Ibu sekalian harap untuk memastikan kembali dokumen (prosedur, instruksi kerja, Formulir, atau check sheet) yang disimpan atau digunakan di area kerja bapak dan ibu telah memiliki stempel dari pengendali dokumen (document control). </b></div>
</div>
</div>



	
		<script type="text/javascript">

 var chart1; // globally available
 $(document).ready(function() {
 chart1 = new Highcharts.Chart({
 chart: {
 renderTo: 'container',
 type: 'column'
 },
 title: {
 text: 'Grafik Jumlah Dokumen Aktif'
 },
 xAxis: {
 categories:
 			['Section'] 
 },
 yAxis: {
 title: {
 text: 'Dokumen '
 }
 },
 series:
 [

<?php
include 'koneksi.php';
$sql = "select DISTINCT section as section from docu order by section"; 
$query = mysql_query($sql) or die(mysql_error());
while ($ret = mysql_fetch_array($query)) {
 $section = $ret['section'];
 //$tanggal = $ret['tanggal'];
 $sql_jumlah = "select distinct count(section) As jumlah from docu where section='$section' and status<>'Obsolate'";

 $query_jumlah = mysql_query($sql_jumlah) or die(mysql_error());
 while ($data = mysql_fetch_array($query_jumlah)) {
 $jumlah = $data['jumlah'];
 }
 ?>
 {
 name: '<?php 	
 		echo $section;
 		?>',
 data: [<?php echo $jumlah; ?>]
 },
<?php } ?>
 ]
 });
 });
 </script>
	<div class="row">
	<div id='container' class="col-xs-12 well well-lg">
	</div>
</div>

<div class="">
	<div class="row">
		<div class="col-xs-12 well well-lg">
		<?php $tgl = date('d-m-Y'); ?>
		Latest Uploaded Document(Today &nbsp;<?php echo $tgl;?>):
		<table>
		<tr>
		<?php 
		$query="SELECT no_doc, file FROM docu WHERE doc_type = 'Procedure' AND tgl_upload = '$tgl' AND STATUS = 'Review' ORDER BY no_drf LIMIT 1 ";
		$res=mysql_query($query)or die(mysql_error());
	
	  ?>
		<td>Procedure</td><td>:</td><td>  <?while ($data=mysql_fetch_array($res)){ ?><a href="document/<?php echo "$data[file]"; ?>"> <?echo $data[no_doc];?> </a> </td> <?}?>
		</tr>
		<tr>
		<?php 
		$query="SELECT no_doc, file FROM docu WHERE doc_type = 'WI' AND tgl_upload = '$tgl' AND STATUS = 'Review' ORDER BY no_drf LIMIT 1 ";
		$res=mysql_query($query)or die(mysql_error());
	
	  ?>
		<td>Work Instruction</td><td>:</td><td> <? while ($data=mysql_fetch_array($res)){ ?> <a href="document/<?php echo "$data[file]"; ?>"> <?echo $data[no_doc];?> </a> </td> <?}?>
		</tr>
		<tr>
		<?php 
		$query="SELECT no_doc, file FROM docu WHERE doc_type = 'Form' AND tgl_upload = '$tgl' AND STATUS = 'Review' ORDER BY no_drf LIMIT 1 ";
		$res=mysql_query($query)or die(mysql_error());
	
	  ?>
		<td>Form</td><td>:</td><td><? while ($data=mysql_fetch_array($res)){ ?> <a href="document/<?php echo "$data[file]"; ?>"> <?echo $data[no_doc];?> </a> </td> <?}?>
		</tr>
		</table>
		</div>
	</div>
</div>

<div class="">
	<div class="row">
		<div class="col-xs-12 well well-lg">
		<?php $tgl = date('d-m-Y'); ?>
		Latest Approved Document(Today &nbsp;<?php echo $tgl;?>):
		<table>
		<tr>
		<?php 
		$query="SELECT no_doc, file FROM docu WHERE doc_type = 'Procedure' AND final = '$tgl' AND STATUS = 'Review' ORDER BY no_drf LIMIT 1 ";
		$res=mysql_query($query)or die(mysql_error());
	
	  ?>
		<td>Procedure</td><td>:</td><td>  <?while ($data=mysql_fetch_array($res)){ ?><a href="document/<?php echo "$data[file]"; ?>"> <?echo $data[no_doc];?> </a> </td> <?}?>
		</tr>
		<tr>
		<?php 
		$query="SELECT no_doc, file FROM docu WHERE doc_type = 'WI' AND final = '$tgl' AND STATUS = 'Review' ORDER BY no_drf LIMIT 1 ";
		$res=mysql_query($query)or die(mysql_error());
	
	  ?>
		<td>Work Instruction</td><td>:</td><td> <? while ($data=mysql_fetch_array($res)){ ?> <a href="document/<?php echo "$data[file]"; ?>"> <?echo $data[no_doc];?> </a> </td> <?}?>
		</tr>
		<tr>
		<?php 
		$query="SELECT no_doc, file FROM docu WHERE doc_type = 'Form' AND final = '$tgl' AND STATUS = 'Review' ORDER BY no_drf LIMIT 1 ";
		$res=mysql_query($query)or die(mysql_error());
	
	  ?>
		<td>Form</td><td>:</td><td><? while ($data=mysql_fetch_array($res)){ ?> <a href="document/<?php echo "$data[file]"; ?>"> <?echo $data[no_doc];?> </a> </td> <?}?>
		</tr>
		</table>
		</div>
	</div>
</div>

</body>
</html>