<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<br />
<br />
<br />
<br />
<br />
<br />
<?php include ("header.php"); ?>
<img src="script2.php">
</body>
</html>