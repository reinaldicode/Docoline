<?php

include('header.php');
?>
<!DOCTYPE html>








<br />
<br />
<br />
<br />
<br />


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="conf_user.php" class="btn btn-primary"><span class="glyphicon glyphicon-user"></span>&nbsp;User</a>
<a href="conf_device.php" class="btn btn-primary"><span class="glyphicon glyphicon-hdd"></span>&nbsp;Device</a>
<a href="conf_process.php" class="btn btn-primary"><span class="glyphicon glyphicon-briefcase"></span>&nbsp;Process</a>
<a href="conf_section.php" class="btn btn-primary"><span class="glyphicon glyphicon-flag"></span>&nbsp;Section</a>