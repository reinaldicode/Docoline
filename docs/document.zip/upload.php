<?php

include('header.php');

?>

<br />
<br />


<script type="text/javascript">

document.ready = function() {
document.getElementById('section').onchange = disablefield;

}

function disablefield()
{
if ( document.getElementById('section').value != 'Production Section' )
{
	
document.getElementById('device').readonly = true;
document.getElementById('process').readonly = true;
}
else{
	document.getElementById('device').readonly = false;
	document.getElementById('process').readonly = false;
}

}

</script>

<script type="text/javascript">
			$(document).ready(function() {
				$('#wait_1').hide();
				$('#device').change(function(){
				  $('#wait_1').show();
				  $('#result_1').hide();
				  $.get("func2.php", {
					func: "device",
					drop_var: $('#device').val()
				  }, function(response){
					$('#result_1').fadeOut();
					setTimeout("finishAjax1('result_1', '"+escape(response)+"')", 400);
				  });
					return false;
				});



			});




			function finishAjax1(id, response) {
			  $('#wait_1').hide();
			  $('#'+id).html(unescape(response));
			  $('#'+id).fadeIn();

			  $('#wait_2').hide();
				$('#device').change(function(){
					
				  $('#wait_2').show();
				  $('#result_2').hide();
				  $.get("func.php", {
					func: "device",
					drop_var2: $('#device').val()
				  }, function(response){
					$('#result_2').fadeOut();
					setTimeout("finishAjax('result_2', '"+escape(response)+"')", 400);
				  });
					return false;
				});

				function finishAjax(id, response) {
			  $('#wait_2').hide();
			  $('#'+id).html(unescape(response));
			  $('#'+id).fadeIn();

			}

			}

			function finishAjax(id, response) {
			  $('#wait_2').hide();
			  $('#'+id).html(unescape(response));
			  $('#'+id).fadeIn();

			}
			</script>
	
</head>





<?php

//include 'index.php';
include 'koneksi.php';

 ?>
<br />
<br />
<br />
<div class="row">
<div class="col-xs-1"></div>
<div class="col-xs-6 well well-lg">
 <h2>Add New Document</h2>

				<form action="" method="POST" enctype="multipart/form-data">
				 <table class="table">
				 	<tr cellpadding="50px">
				 		<td>User ID &nbsp;&nbsp;</td>
				 		<td>:&nbsp;	&nbsp; &nbsp;</td>
				 		<td><input type="text" class="form-control" name="user" readonly="readonly" value="<?php echo $nrp;?>"></td>
				 	</tr>
				 	<tr cellpadding="50px">
				 		<td>Email &nbsp;&nbsp;</td>
				 		<td>:&nbsp;	&nbsp; &nbsp;</td>
				 		<td><input type="text" class="form-control" name="email" readonly="readonly" value="<?php echo $email;?>" ></td>
				 	</tr>
				 	<tr>
				 	<?php
				 	$sql1="select * from section where id_section='$sec' ";
				 	
				 	$ses_sql=mysql_query($sql1);
				 	$row1 = mysql_fetch_array($ses_sql);
				 	$se=$row1['section_dept'];
				 	 ?>
				 		<td>Department </td>
				 		<td>:</td>
				 		<td><input type="text" class="form-control" name="dep" readonly="readonly" value="<?php echo $se;?>"></td>
				 	</tr>
				 	<tr cellpadding="50px">
				 		<td>No. Document &nbsp;&nbsp;</td>
				 		<td>:&nbsp;	&nbsp; &nbsp;</td>
				 		<td><input type="text" class="form-control" name="nodoc"></td>
				 	</tr>
				 	<tr cellpadding="50px">
				 		<td>No. Revision &nbsp;&nbsp;</td>
				 		<td>:&nbsp;	&nbsp; &nbsp;</td>
				 		<td><input type="text" class="form-control" name="norev">
				 		<input type="hidden" name="state" value=<?php echo $state;?> ></td>
				 	</tr>

				 	<tr>
				 		<td>Review To</td>
				 		<td>:</td>
				 		<td>
				 			
						 <select name="revto" class="form-control">
										<option value="-"> --- Select --- </option>
										
										<option value="Issue"> Issue </option>
										<option value="Revision"> Revision </option>
										<option value="Cancel"> Cancel </option>
									
										</option>
									</select>
				 		</td>
				 	</tr>

				 	<tr>
				 		<td>Category</td>
				 		<td>:</td>
				 		<td>
				 			
						 <select name="cat" class="form-control">
										<option value="-"> --- Select --- </option>
										
										<option value="Internal"> Internal </option>
										<option value="External"> External </option>
										
									
										</option>
									</select>
				 		</td>
				 	</tr>

				 	<tr>
				 		<td>Document Type</td>
				 		<td>:</td>
				 		<td>
				 			
						 <select name="type" class="form-control">
										<option value="-"> --- Select Type --- </option>
										
										<option value="Form"> Form </option>
										<option value="Procedure"> Procedure </option>
										<option value="WI"> WI </option>
									
										</option>
									</select>
				 		</td>
				 	</tr>

				 	<tr>
				 		<td>Section</td>
				 		<td>:</td>
				 		<td>
				 			<?php 
						$sect="select * from section order by id_section";
						$sql_sect=mysql_query($sect);

					?>
						 <select id="section" name="section" class="form-control" >
										<option value="-"> --- Select Section --- </option>
										<?php while($data_sec = mysql_fetch_array( $sql_sect )) 
										{ ?>
										<option value="<?php echo "$data_sec[id_section]"; ?>"> <?php echo "$data_sec[sect_name]"; ?> </option>
										<?php } ?>
										</option>
									</select>
				 		</td>
				 	</tr>


					<tr>
				 		<td>Device</td>
				 		<td>:</td>
				 		<td>
				 			<?php 
						$sect="select * from device where status='Aktif' order by group_dev";
						$sql_sect=mysql_query($sect);

					?>
						 <select id="device" name="device" class="form-control" >
										<option value="-"> --- Select Device --- </option>
										<?php while($data_sec = mysql_fetch_array( $sql_sect )) 
										{ ?>
										<option value="<?php echo "$data_sec[name]"; ?>"> <?php echo "$data_sec[name]"; ?> </option>
										<?php } ?>
										</option>
									</select>
				 		</td>
				 	</tr>


				 	<tr>
				 		<td>Process</td>
				 		<td>:</td>
				 		<td>
				 			 <span id="wait_1" style="display: none;">
					<img alt="Please Wait" src="images/wait.gif"/>
					</span>
					<span id="result_1" style="display: none;">
						
					</span>
				 		</td>
				 	</tr>

				 	<tr>
				 		<td>Doc. Title</td>
				 		<td>:</td>
				 		<td><input type="text" class="form-control" name="title"></td>
				 	</tr>

				 	<tr>
				 		<td>Doc. Description</td>
				 		<td>:</td>
				 		<td >
				 		<textarea  class="form-control" name="desc" cols="40" rows="10" wrap="physical"></textarea>
                	    </td>
				 	</tr>

				 	<tr>
				 		<td>Requirement Document</td>
				 		<td>:</td>
				 		<td >
							
					     
					      <table>
					     <tr><input type="radio" aria-label="ISO 9001" name="iso" value="1" >&nbsp; ISO 9001 <br /></tr>
					        <tr><input type="radio" aria-label="ISO 14001" name="iso" value="2" >&nbsp; ISO 14001 <br /></tr>
					        <tr><input type="radio" aria-label="OHSAS" name="iso" value="3" >&nbsp; OHSAS <br /></tr>
					      </table>
					 
					     
					   
						      
						     
						
                	    </td>
				 	</tr>

				 	<tr>
				 		<td>Related/Addopted Document</td>
				 		<td>:</td>
				 		<td>
				 		<input type="text" class="form-control" name="rel[1]">
				 		<input type="text" class="form-control" name="rel[2]">
				 		<input type="text" class="form-control" name="rel[3]">
				 		<input type="text" class="form-control" name="rel[4]">
				 		<input type="text" class="form-control" name="rel[5]">
				 		</td>
				 	</tr>

				 	<tr>
				 		<td>Upload Document</td>
				 		<td>:</td>
				 		<td>
				 		<input type="file" class="form-control" name="file">
				 		</td>
				 	</tr>

				 	<tr>
				 		<td>Upload File Master</td>
				 		<td>:</td>
				 		<td>
				 		<input type="file" class="form-control" name="master">
				 		</td>
				 	</tr>

				 	<tr>
				 		<td>Revision reason/history</td>
				 		<td>:</td>
				 		<td >
				 		<textarea  class="form-control" name="hist" cols="40" rows="10" wrap="physical"></textarea>
                	    </td>
				 	</tr>

				 	<tr>
				 		<td></td>
				 		<td></td>
				 		<td>
				 			<input type="submit" value="Save" name="submit" class="btn btn-success">
				 		</td>
				 	</tr>
				</form>
				 </table>
				 </div>

 </div>


 <?php
if (isset($_POST['submit'])){


include 'koneksi.php';

$nama=$_POST['user'];
$email=$_POST['email'];
$dep=$_POST['dep'];
$nodoc=$_POST['nodoc'];
$norev=$_POST['norev'];
$revto=$_POST['revto'];
$type=$_POST['type'];
$section=$_POST['section'];
$device=$_POST['device'];
$process=$_POST['process'];
$title=$_POST['title'];
$desc=$_POST['desc'];
$cat=$_POST['cat'];
$iso=$_POST['iso'];
//$master=$POST['master']
$tgl = date('d-m-Y');
$state=$_POST['state'];

if ($state=='Admin'){
	$sta_doc='Approved';
} else {$sta_doc='Review';}

$hist=$_POST['hist'];

$target_dir = "$type/";
$target_file = $target_dir . basename($_FILES["file"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image

    
     if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
    }
   
$target_dir = "master/";
$target_file = $target_dir . basename($_FILES["master"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image

    
     if (move_uploaded_file($_FILES["master"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["master"]["name"]). " has been uploaded.";
    }
   


$nama_file=basename($_FILES["file"]["name"]);
$nama_master=basename($_FILES["master"]["name"]);








$sql="insert into docu(no_drf,user_id,email,dept,no_doc,no_rev,rev_to,doc_type,section,device,process,title,descript,iso,file,history,status,tgl_upload,category,final,file_asli)
 values ('','$nama','$email','$dep','$nodoc','$norev','$revto','$type','$section','$device','$proc','$title','$desc','$iso','$nama_file','$hist','$sta_doc','$tgl','$cat','','$nama_master')";

// echo $sql;
$res=mysql_query($sql);
$drf=mysql_insert_id();


$jumlah = count($_POST["rel"]);

for($i=0; $i < $jumlah; $i++) 
{
    $no_doc=$_POST["rel"][$i];

    if ($no_doc <> '' ){
	
  $q=mysql_query("insert into rel_doc(id,no_drf,no_doc) values ('','$drf','$no_doc')"); 
}
}

if ($norev=='0'){
	$insert="insert into distribusi(id_dis,no_drf,pic,give,date_give,location,receiver,retrieve,retrieve_from,retrieve_date)
							 values('','$drf','','','','','','','','')";
					$result=mysql_query($insert);
}



if ($res){
	if($state<>'Admin'){
?>

<script language='javascript'>
							alert('Document Uploaded , please set the approvers');
							document.location='set_approver.php?id_doc=<?php echo $drf?>&section=<?php echo $section?>&type=<?php echo $type?>&iso=<?php echo $iso?>&nodoc=<?php echo $nodoc;?>&title=<?php echo $title;?>';
						</script>

<?php 
}
else {
	?>
<script language='javascript'>
							alert('Document Uploaded');
							document.location='index_login.php';
						</script>

	<?
}
}
//else{ echo "Error: " . $sql . "<br>" . $conn->error;}
 }
 ?>