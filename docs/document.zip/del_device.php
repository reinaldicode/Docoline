<?php
 include ('koneksi.php');
 $query="delete from device where id_device='$id' ";
// $id_doc=
	$hasil=mysql_query($query);
	if ($hasil){
	?>
	<script language='javascript'>
							alert('Device removed');
							document.location='conf_device.php';
						</script>
						<?
	}
	
	
	
	?>