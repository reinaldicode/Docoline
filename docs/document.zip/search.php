<?php

include('header.php');
?>

<br />
<br />
<br />
<br />




	
	
	
	<link href="bootstrap/css/bootstrap.min.css" media="all" type="text/css" rel="stylesheet">
		<link href="bootstrap/css/bootstrap-responsive.min.css" media="all" type="text/css" rel="stylesheet">
		<link href="bootstrap/css/facebook.css" media="all" type="text/css" rel="stylesheet">
		
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<script src="bootstrap/js/bootstrap-dropdown.js"></script>
		<script src="bootstrap/js/facebook.js"></script>
	
	<link rel="stylesheet" href="bootstrap/css/datepicker.css">
	<link rel="stylesheet" href="bootstrap/css/bootstrap-select.min.css">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
		 <script src="bootstrap/js/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/script.js"></script>
		<style type="text/css">
		.auto-complete{
			float:left;
			z-index:9999;
		}
		</style>
	
	
</head>





<?php

//include 'index.php';
include 'koneksi.php';

 ?>
    
    


	 <?php require_once('Connections/config.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_config, $config);
$query_rsData = "SELECT distinct no_doc FROM docu ORDER BY no_doc ASC";
$rsData = mysql_query($query_rsData, $config) or die(mysql_error());
$row_rsData = mysql_fetch_assoc($rsData);
$totalRows_rsData = mysql_num_rows($rsData);

mysql_select_db($database_config, $config);
$query_title = "SELECT distinct title FROM docu ORDER BY title ASC";
$title = mysql_query($query_title, $config) or die(mysql_error());
$row_title = mysql_fetch_assoc($title);
$totalRows_title = mysql_num_rows($title);
?>
<!doctype html>

<meta charset="utf-8">

<link rel="stylesheet" href="jquery-ui-1.10.3/themes/base/jquery.ui.all.css">
	<script src="jquery-ui-1.10.3/jquery-1.9.1.js"></script>
	<script src="jquery-ui-1.10.3/ui/jquery.ui.core.js"></script>
	<script src="jquery-ui-1.10.3/ui/jquery.ui.widget.js"></script>
	<script src="jquery-ui-1.10.3/ui/jquery.ui.position.js"></script>
	<script src="jquery-ui-1.10.3/ui/jquery.ui.menu.js"></script>
	<script src="jquery-ui-1.10.3/ui/jquery.ui.autocomplete.js"></script>
	
	<script>
	$(function() {
		var availableTags = [
		<?php do { ?>
			"<?php echo $row_rsData['no_doc']; ?>",
		<?php } while($row_rsData = mysql_fetch_assoc($rsData)); ?>
		];
		$( "#cari" ).autocomplete({
			source: availableTags
		});
	});
	</script>

	<script>
	$(function() {
		var availableTags = [
		<?php do { ?>
			"<?php echo $row_title['title']; ?>",
		<?php } while($row_title = mysql_fetch_assoc($title)); ?>
		];
		$( "#title" ).autocomplete({
			source: availableTags
		});
	});
	</script>

<br />
<br />

<div class="row">
<div class="col-xs-4" style="margin-left=50px;">
  
  <form name="form1" method="GET" action="">
    <p>
      
      Input Document No. : <input name="doc_no" type="text" id="cari" size="60" class="form-control">
    </p>
     <p>
      
      Input Document Title : <input name="title" type="text" id="title" size="60" class="form-control">
    </p>
    <p>
      <input type="submit" name="submit" id="submit" value="Show" class="btn btn-primary">
      <input type="reset" name="submit2" id="submit2" value="Reset" class="btn btn-warning">
    </p>
  </form>
  </div>
  </div>



<?php
mysql_free_result($rsData);
mysql_free_result($title);
?>





    			
    			
    			
	
	

<?php
if (isset($_GET['submit'])){





$no_doc=$_GET['doc_no'];
$title=$_GET['title'];

if ($title==''){
	$sql="select * from docu where no_doc='$no_doc'  order by no_drf limit 150";
}
if ($no_doc==''){
	$sql="select * from docu where title like '%$title%' or title like '$title%' or title like '%$title' order by title limit 150";
}
if ($title<>'' and $no_doc<>''){
	$sql="select * from docu where no_doc='$no_doc' and (title like '%$title%' or title like '$title%' or title like '%$title') order by no_drf limit 150";
}


?>
<br />

<?php

$res=mysql_query($sql);
//$rows = mysql_num_rows($res);

// echo $sql;


?>
<table class="table table-hover">
<thead bgcolor="#00FFFF">
<tr>
	<td>No</td>
	<td>Date</td>
	<td>No Document</td>
	<td>No Rev.</td>
	<td>No. Drf</td>
	<td>Title</td>
	<td>Process</td>
	<td>Section</td>
	<td>Detail</td>
	<td>Action</td>
	
</tr>
</thead>
<?php
$i=1;
while($info = mysql_fetch_array($res)) 
{ ?>
<tbody>
<tr>
	<td>
		<?php echo $i; ?>
	</td>
	<td>
		<?php echo "$info[tgl_upload]";?>
	</td>
	<td>
		<?php echo "$info[no_doc]";?>
	</td>
	<td>
		<?php echo "$info[no_rev]";?>
	</td>
	<td>
		<?php echo "$info[no_drf]";?>
	</td>
	<td>
	<?php if ($info[no_drf]>12955){$tempat=$info[doc_type];} else {$tempat='document';}?>
	<a href="<?php echo $tempat; ?>/<? echo "$info[file]"; ?>" >
		<?php echo "$info[title]";?>
		</a>
	</td>
	<td>
		<?php echo "$info[process]";?>
	</td>
	<td>
		<?php echo "$info[section]";?>
	</td>
	<td>
		<a href="detail.php?drf=<?php echo $info[no_drf];?>&no_doc=<?php echo $info[no_doc];?>" class="btn btn-xs btn-info" title="lihat detail"><span class="glyphicon glyphicon-search" ></span> </a>
		<a href="radf.php?drf=<?php echo $info[no_drf];?>&section=<? echo $info[section]?>" class="btn btn-xs btn-info" title="lihat RADF"><span class="glyphicon glyphicon-eye-open" ></span> </a>
	<a href="lihat_approver.php?drf=<?php echo $info[no_drf];?>" class="btn btn-xs btn-info" title="lihat approver"><span class="glyphicon glyphicon-user" ></span> </a>	
	</td>
	<td>
		<?php if ($state=='Admin' or $state="Originator"){?>
	<a href="edit_doc.php?drf=<?php echo $info[no_drf];?>" class="btn btn-xs btn-primary" title="Edit Doc"><span class="glyphicon glyphicon-pencil" ></span> </a>
	<a href="del_doc.php?drf=<?php echo $info[no_drf];?>" class="btn btn-xs btn-danger" onClick="return confirm('Delete document <?php echo $info[no_doc]?>?')" title="Delete Doc"><span class="glyphicon glyphicon-remove" ></span> </a>
	<?php if ($info[status]=='Approved') {?>
	
	<a data-toggle="modal" data-target="#myModal2" data-id="<?echo $info[no_drf]?>" data-lama="<?echo $info[file]?>" data-status="<?echo $info[status]?>" class="btn btn-xs btn-success sec-file" title="Secure Document">
	<span class="glyphicon glyphicon-play" ></span></a>
	<?php }} ?>
	</td>
	
</tr>
</tbody>
<div>
<?php 
$i++;} 


}


?> 
</div>