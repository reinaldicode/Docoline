<html>
<title>Document Control</title>

<head profile="http://www.global-sharp.com">
	
	
	
	<link href="bootstrap/css/bootstrap.min.css" media="all" type="text/css" rel="stylesheet">
		<link href="bootstrap/css/bootstrap-responsive.min.css" media="all" type="text/css" rel="stylesheet">
		<link href="bootstrap/css/facebook.css" media="all" type="text/css" rel="stylesheet">
		
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<script src="bootstrap/js/bootstrap-dropdown.js"></script>
		<script src="bootstrap/js/facebook.js"></script>
	
	<link rel="stylesheet" href="bootstrap/css/datepicker.css">
	<link rel="stylesheet" href="bootstrap/css/bootstrap-select.min.css">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
		 <script src="bootstrap/js/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap-datepicker.js"></script>

	<style> 
body {
    background-image: url("images/white.jpeg");
    background-color: #cccccc;
    background-repeat: no-repeat;
    background-attachment: fixed;
}
</style>
	
</head>

<body>


	





	<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="images-bar"></span>
        <span class="images-bar"></span>
        <span class="images-bar"></span>
      </button>
      <span class="navbar-brand" href="index.php"><h3>Document Control Online</h3></span>

      <ul class="nav navbar-nav">
        
        <li><a href="index.php" class=""><img src="images/home.png" class="img-responsive" alt="Responsive image"></img>Home</a></li>
		<li><a href="procedure_awal.php" class="bg-success"><img src="images/document.png"><br />Procedure</a></li>
		<li><a href="wi_awal.php" ><img src="images/doc2.png"><br />WI</a></li>		
		<li><a href="form_awal.php" class="bg-success"><img src="images/doc3.png"><br />Form</a></li>
		<li><a href="search_awal.php" ><img src="images/search3.png"><br />Search</a></li>

			  <li class="pull-right"><a href="login.php" class=" bg-success"><img src="images/login.png" class="img-responsive" alt="Responsive image"> &nbsp;Login</a></li>
			  </ul>


    </div>
    <br />
    <br />
      <br />
    <br />


    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      
        
    
    </div>
  </div>
</nav>



<br />
<br />


    
  
	
	