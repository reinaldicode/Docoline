<?php
session_destroy();
session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {
$error = "Username or Password is invalid";
}
else
{
// Define $username and $password
$username=$_POST['username'];
$password=$_POST['password'];
// To protect MySQL injection for Security purpose

// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$connection = mysql_connect("localhost", "root", "123456789");
// Selecting Database
$db = mysql_select_db("doc", $connection);
// SQL query to fetch information of registerd users and finds user match.
$query = mysql_query("select * from users where password='$password' AND username='$username'", $connection);
$rows = mysql_num_rows($query);
//echo "$rows";
if ($rows == 1) {
$_SESSION['login_user']=$username; // Initializing Session
header("location:index_login.php"); // Redirecting To Other Page
//echo "berhasil";
} else {
$error = "Username or Password is invalid";
echo $error;
}
mysql_close($connection); // Closing Connection
}
}
?>