<?php
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
//$connection = mysql_connect("localhost", "root", "");
include ('koneksi.php');
// Selecting Database
//$db = mysql_select_db("doc", $connection);
session_start();// Starting Session
// Storing Session
$user_check=$_SESSION['login_user'];
// SQL Query To Fetch Complete Information Of User
$ses_sql=mysql_query("select * from users where username='$user_check'");
$row = mysql_fetch_array($ses_sql);
$name =$row['name'];
$state =$row['state'];
$nrp=$row['username'];
$sec=$row['section'];
$email=$row['email'];
$pass=$row['password'];
if(!isset($name)){
mysql_close($connection); // Closing Connection
header('Location: login.php'); // Redirecting To Home Page
}
?>