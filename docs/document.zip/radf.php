<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<head profile="http://www.google.com">

<link href="bootstrap/css/bootstrap.min.css" media="all" type="text/css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap-responsive.min.css" media="all" type="text/css" rel="stylesheet">
    <link href="bootstrap/css/facebook.css" media="all" type="text/css" rel="stylesheet">
    
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="bootstrap/js/bootstrap-dropdown.js"></script>
    <script src="bootstrap/js/facebook.js"></script>
  
  <link rel="stylesheet" href="bootstrap/css/datepicker.css">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
     <script src="bootstrap/js/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap-datepicker.js"></script>
        <style type="text/css">
                .container-non-responsive {
        margin-left: auto;
        margin-right: auto;
        padding-left: 15px;
        padding-right: 15px;
        width: 1170px;
}
        </style>


</head>

<div style="margin-left:10px;">

<div class="row" style="margin-left:0px;">
  <div class="col-xs-3">
    
  </div>
  <div class="col-xs-6">
    <h4>REVIEW AND APPROVAL DOCUMENT FORM (RADF)</h4>
  </div>
  <div class="col-xs-3">
    <table border="">
      <tr>
        <td>Document No. &nbsp; DC-055</td>
        
      </tr>
      <tr><td>Rev. No 00</td></tr>
      <tr>
        <td> Eff. Date  April, 01 2009 </td>
      </tr>
    </table>
    
  </div>
</div>

<?
include "koneksi.php";
    $sql_doc="select docu.*,users.name from docu,users where no_drf='$drf' and docu.user_id=users.username";
    $hasil_doc=mysql_query($sql_doc);
    // echo $sql_doc;

?>

<div class="row">
  <br />
  <div class="col-xs-4" style="margin-left:-;">
  

  
  <?
  
    while ($data_doc=mysql_fetch_array ($hasil_doc))
    {
      $drf=$data_doc[no_drf];
      $tanggal=$data_doc[tgl_upload];
      $no_doc=$data_doc[no_doc];
      $title=$data_doc[title];
      $rev=$data_doc[no_rev];
      $nama=$data_doc[name];
      $iso=$data_doc[iso];
      $type=$data_doc[doc_type];
      $his=$data_doc[history];
      $rev_to=$data_doc[rev_to];
  
      
    }
  ?>  

  <table  class=""style="float:left;" border="0"  cellpadding="" cellspacing="" width="" >



<tr>
<td>No. Drf</td><td> : </td>
 <td>
    <a href="document/<? echo "$upd"; ?>" target="_blank">
    &nbsp;<?echo $drf;?> </a></td>
 </tr>

<tbody>


<tr>
<td>Issue Date</td><td> : </td>
  <td height="30px">
     &nbsp;<?echo $tanggal ;?></td>
  
</tr>
<tr>
<td>No. Document</td><td> : </td>
  <td height="30px" >
  
     &nbsp;<?echo $no_doc;?>
   
      </td>
  
</tr>
<tr>
<td>Doc. Title</td><td> : </td>
  <td height="30px" >
  
      &nbsp;<?echo $title;?>
   
    </td>
  
</tr>
<tr>
<td>No. Rev.</td><td> : </td>
  <td height="30px" >
  
     &nbsp;<?echo $rev;?>
   
      </td>
  
</tr>
</tbody>
</table>
<br />
<br />

</div>


  
  </div>


<body>
<table width="1200" height="379" border="1">
  <tr>
        <td colspan="2" rowspan="2" >
              <table width="100%" height="230" border="0">
                <tr>
                  <td style="vertical-align:top;">&nbsp;&nbsp;Reason for issue/cancel/revise document ( alasan mengeluarkan/membatalkan/merevisi dokumen):</td>
                </tr>
                <tr>
                  <td>&nbsp; <?php echo $hist; ?></td>
                </tr>
                <tr>
                  <td style="vertical-align:bottom;">&nbsp;Proposed by :&nbsp; <?php echo $nama; ?></td>
                </tr>
              </table>
        </td>
        <td width="437" height="106">&nbsp; 

            &nbsp;This document is appropriate 
              with requirment of (dokumen ini sesuai dengan persyaratan) :<font size="1" face="arial"><strong>       
              </strong></font><br> 
                
              &nbsp; [<?php if ($iso=='1'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;&nbsp;" ;} ?> ]
              ISO 9001<br>
              &nbsp;&nbsp;[ <?php if ($iso=='2'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;" ;} ?> ]
              ISO 14000<br>
               &nbsp;&nbsp;[ <?php if ($iso=='3'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;" ;} ?> ]
              OHSAS / SMK3<br>
              &nbsp;&nbsp;[&nbsp;&nbsp;&nbsp; &nbsp;]
              Indonesian Law<br>

        </td>
  </tr>
  <tr>
        <td height="128" valign="top">&nbsp;

          &nbsp;&nbsp;Transfer system doc :<br>
               
              &nbsp;&nbsp;[&nbsp;&nbsp;&nbsp;&nbsp;]
              Sequence training<br>
              &nbsp;&nbsp;[&nbsp;&nbsp;&nbsp;&nbsp;]
              Direct training<br>
              &nbsp;&nbsp;[<span class="glyphicon glyphicon-ok"></span> ]
              RADF </p>

        </td>
  </tr>
  <tr>
    <td height="100px" width="200px">&nbsp;
    <input name="" type="checkbox"  >
              Ya / Yes<br> &nbsp;
    <input name="" type="checkbox"  >
              Tidak / No<br> 
    </td>
    <td colspan="2" valign="top">Is this document adopted from external document (ex : Sharp Co. Instruction Doc.,, etc)? (Apakah dokumen ini diadopsi dari dokumen eksternal, misalnya Sharp Co. Instruction Doc., dll ?) If Yes, please write document no. and its title   Instruction Doc., dll(Jika Ya, tuliskan judul dan nomor dokumen tersebut) : </td>
  </tr>
  <tr>
    <td width="200px" height="100px">&nbsp;
    <input name="" type="checkbox"  >
              Ya / Yes<br> &nbsp;
    <input name="" type="checkbox"  >
              Tidak / No<br> </td>
    <td colspan="2">

          Is this issuing/cancelling/revising of document will affect to contents of related procedure/work instruction/ Form form? (apakah pengeluaran/pembatalan/perevisian dokumen ini akan mempengaruhi isi prosedur/instruksi kerja/form catatan   terkait?): 
          <br />
          <br />
          <br />
            [Then do adjustment to related document against this issuing, cancelling or revising(kemudian lakukan penyesuaian terhadap dokumen terkait atas pengeluaran, pembatalan atau perevisian dokumen ini]


    </td>
  </tr>
  </table>
  <table border="1">
  <tr>
        <td height="23" colspan="3" align="center" bgcolor="#5C8A8A">&nbsp; <b>Document's Approval :</b></td>
  </tr>
  <tr align="center" height="30px">
        <strong>
        <td width="400px">Affected Section</td>
        <td width="400px">Status Review</td>
        <td width="400px">Reviewer</td>
        </strong>
  </tr>

  <?php
  $sql_rev="SELECT users.name, users.section, rev_doc.status, rev_doc.tgl_approve FROM users, rev_doc WHERE rev_doc.id_doc ='$drf' AND users.username = rev_doc.nrp and level<7";
  $hasil_rev=mysql_query($sql_rev);

  while ($data_rev=mysql_fetch_array ($hasil_rev))
  {?>
  <tr align="center" height="50px">
      <td><?php echo $data_rev[section]?></td>
      <td>
      <?if ($data_rev[status]=='Review') {?> <img src="images/rev.png">  <?}?>
      <?if ($data_rev[status]=='Approved') {?>  <img src="images/approve.jpg"> <?}?>
      <?if ($data_rev[status]=='Pending') {?>  <img src="images/pending.png"> <?}?>
      </td>
      <td><?php echo $data_rev[name]?></td>

  </tr>
  <?php }
  ?>
  <tr>
    <td>&nbsp;Remark:</td>
    <td>&nbsp;Remark:</td>
    <td>&nbsp;Remark:</td>
  </tr>
  <tr>
      <td>
        <table>

          <tr>
            <td width="" height="100px">&nbsp;
              [<?php if ($rev_to=='Issue'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;&nbsp;" ;} ?> ]
              Issue new Document<br> &nbsp;
              [<?php if ($rev_to=='Revision'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;&nbsp;" ;} ?> ]
              Revise Existing Document<br> &nbsp;
              [<?php if ($rev_to=='Cancel'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;&nbsp;" ;} ?> ]
              Canceled<br> 
            </td>
          </tr>
          <tr>
            <td>
              
            <?php if ($type=="Procedure"){
              $sql_mr="SELECT users.name, users.section, rev_doc.status, rev_doc.tgl_approve FROM users, rev_doc WHERE rev_doc.id_doc ='$drf' AND users.username = rev_doc.nrp and level>7";
              $hasil_mr=mysql_query($sql_mr);
              while ($data_mr=mysql_fetch_array ($hasil_mr))
              {
                $status1=$data_mr[status];
                $nama_mr=$data_mr[name];
              }
              } ?>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <?if ($status1=='Review') {?> <img src="images/rev.png">  <?}?>
              <?if ($status1=='Approved') {?>  <img src="images/approve.jpg"> <?}?>
              <?if ($status1=='Pending') {?>  <img src="images/pending.png"> <?}?>
            </td>
          </tr>
          <tr>
            <td>Approved By: <?echo $nama_mr;?> <br />
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Top Management / MR committee)</td>
          </tr>
        </table>

      </td>

      <td>
        <table>
          <tr>
            <td width="" height="100px">&nbsp;
              [<?php if ($rev_to=='Issue'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;&nbsp;" ;} ?> ]
              Issue new Document<br> &nbsp;
              [<?php if ($rev_to=='Revision'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;&nbsp;" ;} ?> ]
              Revise Existing Document<br> &nbsp;
              [<?php if ($rev_to=='Cancel'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;&nbsp;" ;} ?> ]
              Canceled<br> 
            </td>
          </tr>
          <tr>
            <td>
              

            <?php 
              $sql_dir="SELECT users.name, users.section, rev_doc.status, rev_doc.tgl_approve FROM users, rev_doc WHERE rev_doc.id_doc ='$drf' AND users.username = rev_doc.nrp  and users.section='$section' and level=(select max(level) from users, rev_doc WHERE rev_doc.id_doc ='$drf' AND users.username = rev_doc.nrp  and users.section='$section')";
              // echo $sql_dir;
              $hasil_dir=mysql_query($sql_dir);
              while ($data_dir=mysql_fetch_array ($hasil_dir))
              {
                $status2=$data_dir[status];
                $nama_dir=$data_dir[name];
              
              } ?>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <?if ($status2=='Review') {?> <img src="images/rev.png">  <?}?>
              <?if ($status2=='Approved') {?>  <img src="images/approve.jpg"> <?}?>
              <?if ($status2=='Pending') {?>  <img src="images/pending.png"> <?}?>


            </td>
          </tr>
          <tr>
            <td>Approved By: <?echo $nama_dir;?><br />
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Director / Dept. Head)</td>
          </tr>
        </table>
      </td>

      <td>
        <table>
          <tr>
            <td width="" height="100px">&nbsp;
              [<?php if ($rev_to=='Issue'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;&nbsp;" ;} ?> ]
              Issue new Document<br> &nbsp;
              [<?php if ($rev_to=='Revision'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;&nbsp;" ;} ?> ]
              Revise Existing Document<br> &nbsp;
              [<?php if ($rev_to=='Cancel'){ ?>  <span class="glyphicon glyphicon-ok"></span><?php } else{ echo "&nbsp;&nbsp;&nbsp;&nbsp;" ;} ?> ]
              Canceled<br> 
            </td>
          </tr>
          <tr>
            <td>
              
               <?php 
              $sql_head="SELECT users.name, users.section, rev_doc.status, rev_doc.tgl_approve FROM users, rev_doc WHERE rev_doc.id_doc ='$drf' AND users.username = rev_doc.nrp and (level=7 or level=8) and users.section='$section'";
              // echo $sql_head;
              $hasil_head=mysql_query($sql_head);
              while ($data_head=mysql_fetch_array ($hasil_head))
              {
                $status3=$data_head[status];
                $nama_head=$data_head[name];
              
              } ?>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <?if ($status3=='Review') {?> <img src="images/rev.png">  <?}?>
              <?if ($status3=='Approved') {?>  <img src="images/approve.jpg"> <?}?>
              <?if ($status3=='Pending') {?>  <img src="images/pending.png"> <?}?>

            </td>
          </tr>
          <tr>
            <td>Approved By: <?echo $nama_head;?><br />
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  (Section Head)</td>
          </tr>
        </table>
      </td>
    
  </tr>


</table>

</div>

</body>
</html>