<?php include('session.php'); ?>

<html>
<title>Document Control</title>

<head profile="http://www.global-sharp.com">
	
	
	
	<link href="bootstrap/css/bootstrap.min.css" media="all" type="text/css" rel="stylesheet">
		<link href="bootstrap/css/bootstrap-responsive.min.css" media="all" type="text/css" rel="stylesheet">
		<link href="bootstrap/css/facebook.css" media="all" type="text/css" rel="stylesheet">

		 <script src="bootstrap/js/jquery.min.js"></script>
        <script src="bootstrap/js/bootstrap-datepicker.js"></script>
		
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<script src="bootstrap/js/bootstrap-dropdown.js"></script>
		<script src="bootstrap/js/facebook.js"></script>
	
	<link rel="stylesheet" href="bootstrap/css/datepicker.css">
	<link rel="stylesheet" href="bootstrap/css/bootstrap-select.min.css">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css">

		

	<style> 
body {
    background-image: url("images/white.jpeg");
    background-color: #cccccc;
    background-repeat: no-repeat;
    background-attachment: fixed;
}
</style>

<script type="text/javascript">
$(document).ready(function () {

    $('.chg-pass').click(function () {

        $('span.user-id').text($(this).data('user'));
		var user = $(this).data('user');
     $(".modal-body #user").val( user );
	 
	 var pass = $(this).data('pass');
     $(".modal-body #pass").val( pass );

     var title = $(this).data('title');
     $(".modal-body #title").val( title );
    });

});
</script>
	
</head>

<body >


	





	<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="images-bar"></span>
        <span class="images-bar"></span>
        <span class="images-bar"></span>
      </button>
      <span class="navbar-brand" href="index.php"><h3>Document Online</h3></span>

      <ul class="nav navbar-nav">
        
        <li><a href="index_login.php" class="bg-info"><img src="images/home.png" class="img-responsive" alt="Responsive image"></img>Home</a></li>
        <li><a href="my_doc.php" ><img src="images/text.png"><br />Review</a></li>
        <li><a href="upload.php" class="bg-info"><img src="images/up.png"><br />Upload</a></li>
		<li><a href="procedure_login.php" ><img src="images/document.png"><br />Procedure</a></li>
		<li><a href="wi_login.php" class="bg-info"><img src="images/doc2.png"><br />WI</a></li>		
		<li><a href="form_login.php" ><img src="images/doc3.png"><br />Form</a></li>
		<li><a href="manual.php" class="bg-info"><img src="images/manual.png"><br />Manual</a></li>
		<li><a href="obs_login.php" ><img src="images/reject.png"><br />Obsolate</a></li>
		<li><a href="search.php" class="bg-info"><img src="images/search3.png"><br />Search</a></li>
		<li><a href="script2.php" ><img src="images/graph.png"><br />Grafik</a></li>
		<li><a href="" data-toggle="modal" data-target="#myModal" data-user="<?echo $nrp;?>" data-pass="<?echo $pass;?>" class="bg-info chg-pass"><img src="images/logoff.png"><br />Change</a></li>

		

		<?php if ($state=="Admin"){?>
		<li><a href="config_head.php" ><img src="images/config.png"><br />Config</a></li>
		<li><a href="distribute.php" class="bg-info"><img src="images/dis.png"><br />Distribution</a></li>
		<li class="pull-right"><a href="logout.php" onClick="return confirm('Logout?')" ><img src="images/logout.png" class="img-responsive" alt="Responsive image"> &nbsp;logout</a></li>
		<?php } else if ($state=="PIC"){?>
				<li><a href="distribute.php" ><img src="images/dis.png"><br />Distribution</a></li>
			  <li class="pull-right"><a href="logout.php" onClick="return confirm('Logout?')" class="bg-info"><img src="images/logout.png" class="img-responsive" alt="Responsive image"> &nbsp;logout</a></li>
			 <?php }
			 else{?>
				<li class="pull-right"><a href="logout.php" onClick="return confirm('Logout?')" ><img src="images/logout.png" class="img-responsive" alt="Responsive image"> &nbsp;logout</a></li>	 		
			 	<? } ?>
			  </ul>


    </div>
    <br />
    <br />
      <br />
    <br />


    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      
        
    
    </div>
  </div>
</nav>

</body>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                 <h4 class="modal-title" id="myModalLabel">Change Password</h4>

            </div>
            <div class="modal-body">
                <form name="chg_pass" method="POST" action="chg_pass.php" enctype="multipart/form-data">

                   	<div class="modal-body">
						
						<input type="hidden" name="user" id="user" class="form-control" value=""/>
						<input type="hidden" name="pass" id="pass" class="form-control" value=""/>
						<input type="password" name="lama" placeholder="Type Old Password" id="lama" class="form-control" value=""/>
						<input type="password" name="baru" id="baru" placeholder="Type New Password " class="form-control">
						<input type="password" name="conf" id="conf" placeholder="Confirm New Password" class="form-control">
					</div>
					
                    <div class="modal-footer"> <a class="btn btn-default" data-dismiss="modal">Cancel</a>

                        <input type="submit" name="upload" value="Update" class="btn btn-primary">
                    </div>
                </form>
            </div>
           
        </div>
    </div>
</div>