<?php
 include ('koneksi.php');
 $query="delete from docu where no_drf='$drf' ";
// $id_doc=
	$hasil=mysql_query($query);
	if ($hasil){
	?>
	<script language='javascript'>
							alert('Document removed');
							document.location='my_doc.php';
						</script>
						<?
	}
	
	
	
	?>